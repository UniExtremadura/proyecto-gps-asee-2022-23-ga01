package es.unex.proyectogps_asee.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ListAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

import es.unex.proyectogps_asee.R;
import es.unex.proyectogps_asee.modelos.Juego;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    private List<Juego> listaJuegos;
    private LayoutInflater mInflater;
    private Context context;

    public Adapter(List<Juego> listaJuegos, Context context){
        this.listaJuegos = listaJuegos;
        this.context = context;
        mInflater = LayoutInflater.from(context);
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.item_de_lista_de_juegos, null);
        ListAdapter.ViewHolder viewHolder = new ListAdapter.ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(ListAdapter.ViewHolder holder, final int position) {
        holder.bindData(listaJuegos.get(position));
    }

    public void setItems(List<Juego> items){listaJuegos = items;}

    @Override
    public int getItemCount() {
        return listaJuegos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder{

        private TextView tv1;
        private TextView tv2;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);

            tv1 = itemView.findViewById(R.id.tv1);
            tv2 = itemView.findViewById(R.id.tv2);
        }

        void bindData(final Juego item){
            tv1.setText(item.getNombre());
            tv2.setText(item.getRating().toString());
        }
    }
}
